LCARS SDK 

14241.1 - 

INCLUDES REWRITTEN OBJECT DEFINITION AND SETTINGS HANDLER. 
LARGE ELBOWS AND BLOCK VERSION ‘OVAL’ HAVE BEEN ADDED FOR 
ELEMENT SELECTION. UPDATED TERMS OF SERVICE.

14243.101 -
BF:  href value not applied to element attribute
BF:  Sequence timing not being applied.
BF:  Dialog Templates, correct Title object definition syntax.

14278.102 - 
BF:  Removed accidental false string from settings.
CO:  Active state tweak for complex button sub-elements.

14304.103 - 
BF:  Password setting variable
EH:  Viewscreen application environment included.




Legend - 
BF:  Bug Fix
CO:  Cosmetic
EH:  Enhancement
