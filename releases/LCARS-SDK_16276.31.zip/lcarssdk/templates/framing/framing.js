/** LCARS SDK 16276.31
* This file is a part of the LCARS SDK.
* https://github.com/AricwithanA/LCARS-SDK/blob/master/LICENSE.md
* For more information please go to http://www.lcarssdk.org.
**/

LCARS.templates.sdk.framing = {
	typeA:{
					
	}        
};