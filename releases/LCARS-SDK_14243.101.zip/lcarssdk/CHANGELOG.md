LCARS SDK 

14241.1 - 

INCLUDES REWRITTEN OBJECT DEFINITION AND SETTINGS HANDLER. 
LARGE ELBOWS AND BLOCK VERSION ‘OVAL’ HAVE BEEN ADDED FOR 
ELEMENT SELECTION. UPDATED TERMS OF SERVICE.

14243.101 -
Bug Fix:  href value not applied to element attribute
Bug Fix:  Sequence timing not being applied.
Bug Fix:  Dialog Templates, correct Title object definition syntax.


